import asyncio

symbols = ['AVAXUSDT','BTCUSDT','ETHUSDT']

_base = 'wss://stream.binance.com:9443 /ws/@miniTicker'

#
# import requests
# def get_real_time:
#     requests.get(_base)
#
#     pass